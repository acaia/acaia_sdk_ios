//
//  AcaiaSDK.h
//  AcaiaSDK
//
//  Created by Michael Wu on 2018/10/30.
//  Copyright © 2018 Acaia Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
// #import <AcaiaSDK/AcaiaManager.h>
//! Project version number for AcaiaSDK.
FOUNDATION_EXPORT double AcaiaSDKVersionNumber;

//! Project version string for AcaiaSDK.
FOUNDATION_EXPORT const unsigned char AcaiaSDKVersionString[];

#import "AcaiaManager.h"
